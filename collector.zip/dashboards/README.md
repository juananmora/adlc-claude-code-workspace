# Importar el dashboard de agentes

1. En Grafana, abre **Dashboards > New > Import**.
2. Sube `agent-usage.json`.
3. Asigna las fuentes Prometheus, Tempo y Loki que crea LGTM.
4. Abre el dashboard y espera al menos 15 segundos después de generar trazas: el Collector convierte los spans a métricas `spanmetrics` periódicamente.

## Qué mide

- Volumen y errores de operaciones de agente.
- Latencia p95 de spans.
- Operaciones cuyo nombre contiene `mcp` o `tool`.
- Top de tools/MCP y operaciones lentas.

## Convención recomendada para instrumentación propia

Añade estos atributos de recurso, no como etiquetas de métrica personales:

```
service.name=copilot|codex|tu-agente
ai.product=copilot|codex
team.id=nombre-equipo
deployment.environment=development|production
```

Para que la sección MCP sea significativa, nombra los spans de manera estable, por ejemplo `mcp.github.search_issues`, `tool.read_file` o `tool.apply_patch`. No incluyas argumentos, prompts ni rutas de archivos en el nombre del span.
