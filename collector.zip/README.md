# Observabilidad local de Copilot y Codex

Entorno de desarrollo para comprobar el recorrido OTLP completo:

`cliente -> OTel Collector -> Grafana LGTM -> Grafana`

LGTM es el paquete local de Grafana que contiene Grafana, Tempo, Prometheus y Loki. Los datos se guardan en el volumen Docker `lgtm-data`; no es una instalación para producción.

## Requisitos

- Docker Engine 24+ y Docker Compose v2.
- Puertos libres en el equipo: `3000`, `4317` y `4318`.
- GitHub Copilot con OTel habilitado en un cliente compatible y/o Codex CLI instalado.

## Arranque

Desde este directorio:

```bash
docker compose pull
docker compose up -d
docker compose ps
```

Abre http://localhost:3000. En la imagen LGTM de desarrollo, Grafana normalmente queda disponible sin configuración adicional; si pide credenciales, consulta el log inicial:

```bash
docker compose logs lgtm
```

Comprueba que el Collector escucha y reenvía datos:

```bash
docker compose logs -f collector
```

Para parar el laboratorio conservando sus datos:

```bash
docker compose down
```

Para reiniciarlo desde cero (borra trazas, métricas y logs locales):

```bash
docker compose down -v
```

## Prueba sin Copilot ni Codex

Primero valida la ruta con el generador incluido. Ejecuta los tres comandos y espera unos segundos:

```bash
docker compose --profile tools run --rm telemetrygen traces --otlp-endpoint collector:4317 --otlp-insecure --duration 30s --rate 1
docker compose --profile tools run --rm telemetrygen metrics --otlp-endpoint collector:4317 --otlp-insecure --duration 30s --rate 1
docker compose --profile tools run --rm telemetrygen logs --otlp-endpoint collector:4317 --otlp-insecure --duration 30s --rate 1
```

En Grafana, abre **Explore** y selecciona Tempo, Prometheus o Loki. Si no aparecen señales, mira `docker compose logs collector` y `docker compose logs lgtm`.

## Dashboard de agentes, MCP y tools

El directorio `dashboards/` contiene `agent-usage.json`, importable desde **Dashboards > New > Import**. Mide operaciones de agente, errores, p95 de duración y el uso de spans cuyo nombre contiene `mcp` o `tool`. Consulta `dashboards/README.md` para el procedimiento y la convención de nombres.

## Conectar Codex CLI

1. Copia la sección de `examples/codex-config.toml` a `~/.codex/config.toml`.
2. Carga los atributos de ejemplo antes de lanzar Codex:

   ```bash
   source examples/codex-env.sh
   codex
   ```

3. Realiza algunas tareas con Codex y busca la señal en Explore > Prometheus.

El ejemplo usa OTLP/HTTP y el Collector local. Para Codex, la documentación pública actual describe un exportador de **métricas**; no presupongas que emitirá trazas o logs de la sesión. Mantén los atributos de persona fuera de este laboratorio o usa valores pseudonimizados.

## Conectar GitHub Copilot

Configura en el cliente compatible de Copilot la telemetría OTel para enviar al endpoint:

```
http://localhost:4318
```

En clientes que solicitan una URL de señal específica, usa la base OTLP HTTP y permite que el cliente añada la ruta que corresponda. Para una configuración gestionada, usa el bloque `telemetry` de la política empresarial de GitHub; configura `enabled`, endpoint, headers y token conforme a la versión exacta de tu cliente.

Para evitar inventar claves que cambian entre VS Code, JetBrains, CLI y políticas gestionadas, consulta la documentación oficial vinculada abajo y pega su esquema exacto. En local no introduzcas prompts, respuestas, argumentos de herramientas ni tokens reales. GitHub indica que, por defecto, ese contenido no se captura.

Después de habilitarlo, abre una sesión de agente de Copilot y usa herramientas (por ejemplo, lectura y edición de un fichero). En Tempo deberías ver la secuencia de spans de la sesión; en Prometheus, las métricas de tokens/uso; los eventos se podrán consultar según cómo los emita el cliente.

## Consultas iniciales en Grafana

Usa estos filtros en Explore mientras confirmas la ingesta:

- **Tempo:** filtra por `resource.service.name = "codex"` o por el servicio del cliente Copilot.
- **Prometheus:** busca métricas cuyo nombre incluya `token`, `gen_ai`, `copilot` o `codex`.
- **Loki:** `{deployment_environment="development"}` y después filtra por `trace_id` si existe.

## Límites del laboratorio

- Está pensado para una sola máquina, sin autenticación, TLS, retención ni alta disponibilidad.
- El Collector acepta cualquier dato en `localhost`; no publiques los puertos `4317`/`4318` en una red compartida.
- No uses etiquetas de métrica de alta cardinalidad (`user.id`, prompt, ruta de fichero, trace ID).
- Para producción sustituye LGTM por Grafana/Tempo/Loki/Mimir gestionados o desplegados por separado, añade SSO, TLS, secretos, cuotas, sampling y almacenamiento de objetos.

## Referencias

- GitHub: [OpenTelemetry para monitorizar agentes](https://docs.github.com/en/copilot/concepts/enterprise/opentelemetry).
- GitHub: [instrumentación OTel para el Copilot SDK](https://docs.github.com/en/enterprise-cloud@latest/copilot/how-tos/copilot-sdk/observability/opentelemetry).
- Grafana: [OTel Collector con Tempo](https://grafana.com/docs/tempo/latest/set-up-for-tracing/instrument-send/set-up-collector/otel-collector/).
- AWS: [configurar las métricas OTel de Codex](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/coding-agents-codex-bearer-token.html).
