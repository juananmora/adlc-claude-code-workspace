# Source this in the shell BEFORE launching `codex`.
# Replace values with non-sensitive, stable organizational dimensions.
export OTEL_RESOURCE_ATTRIBUTES='service.name=codex,ai.product=codex,service.namespace=developer-tools,team.id=platform,department=engineering'
